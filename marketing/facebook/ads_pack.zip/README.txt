﻿Contenu :
- linkedin_posts.txt (textes prêts à copier)
- instagram_captions.txt (caption + plan stories)
- ads_tracking.csv (suivi simple)

URL : https://860607.github.io/money-product/
