﻿# Guide Pratique - Devenir Freelance

Author: BIBI ONDOUA
Version: 1.0.0

Who is this for?
- New freelancers
- Career switchers
- Students

What you get
- A simple 30-day plan
- Email scripts
- Checklists
