# Guide Pratique - Devenir Freelance

Author: BIBI ONDOUA
Version: 1.0.0

Who is this for?
- New freelancers
- Career switchers
- Students

What you get
- A simple 30-day plan
- Email scripts
- Checklists




# Days 1-7 - Foundations
- Positioning
- Clear offer
- Mini portfolio

Exercise: write your 3-line offer.




# Email scripts
Subject: Quick idea for [Company]

Hello [Name],
I can help you with [benefit]. May I send a 3-point plan?

Best,
BIBI ONDOUA




# Guide Pratique - Devenir Freelance

Author: BIBI ONDOUA
Version: 1.0.0

Who is this for?
- New freelancers
- Career switchers
- Students

What you get
- A simple 30-day plan
- Email scripts
- Checklists




# Days 1-7 - Foundations
- Positioning
- Clear offer
- Mini portfolio

Exercise: write your 3-line offer.




# Email scripts
Subject: Quick idea for [Company]

Hello [Name],
I can help you with [benefit]. May I send a 3-point plan?

Best,
BIBI ONDOUA




