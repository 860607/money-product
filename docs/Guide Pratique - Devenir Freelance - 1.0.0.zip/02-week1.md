﻿# Days 1-7 - Foundations
- Positioning
- Clear offer
- Mini portfolio

Exercise: write your 3-line offer.
