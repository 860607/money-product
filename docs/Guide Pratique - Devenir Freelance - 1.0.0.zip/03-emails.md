﻿# Email scripts
Subject: Quick idea for [Company]

Hello [Name],
I can help you with [benefit]. May I send a 3-point plan?

Best,
BIBI ONDOUA
